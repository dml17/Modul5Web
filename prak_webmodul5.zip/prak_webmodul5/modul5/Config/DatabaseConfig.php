<?php
namespace modul5\Config;

class DatabaseConfig {
    public $host = "localhost";
    public $user = "root";
    public $password = "";
    public $database_name = "sayur";
    public $port = 3306;
}
