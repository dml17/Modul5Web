<?php

namespace modul5\Controller;

include "Traits/ApiResponseFormatter.php";
include "Models/Product.php";

use modul5\Models\Product;
use modul5\Traits\ApiResponseFormatter;

class ProductController{
    use ApiResponseFormatter;
    public function index(){
        $productModel = new Product();
        $response = $productModel->findAll();
        return $this->apiResponse(200, "success", $response);
    }

    public function getById($id){
        $productModel = new Product();
        $response = $productModel->findById($id);
        return $this->apiResponse(200, "success", $response);
    }
    
    public function insert(){
        $jsonInput = file_get_contents('php://input');
        $inputData = json_decode($jsonInput, true);

        if(json_last_error()){
            return $this->apiResponse(400, "error invalid input", null);
        }

        $productModel = new Product();
        $response = $productModel->create([
            "nama_sayur" => $inputData["nama_sayur"],
            "warna_sayur" => $inputData["warna_sayur"],
            "id_jenis" => $inputData["id_jenis"]
        ]);
        return $this->apiResponse(200, "success", $response);
    }

    public function update($id){
        $jsonInput = file_get_contents('php://input');
        $inputData = json_decode($jsonInput, true);
    
        if(json_last_error()){
            return $this->apiResponse(400, "error invalid input", null);
        }
    
        $productModel = new Product();
        $response = $productModel->update([
            "nama_sayur" => $inputData["nama_sayur"],
            "warna_sayur" => $inputData["warna_sayur"],
            "id_jenis" => $inputData["id_jenis"]
        ], $id);
    
        return $this->apiResponse(200, "success", $response);
    }
    

    public function delete($id){
        $productModel = new Product();
        $response = $productModel->destroy($id);

        return $this->apiResponse(200, "succes", $response);
    }

    public function getProductsWithPackages()
    {
        $productModel = new Product;
        $response = $productModel->findAllWithCategories();

        return $this->apiResponse(200, "success", $response);
    }


}