<?php

namespace modul5\Models;

include "Config/DatabaseConfig.php";

use modul5\config\DatabaseConfig;
use mysqli;

class Product extends DatabaseConfig {
    public $conn;

    public function __construct()
    {
        $this->conn = new mysqli($this->host, $this->user, $this->password, $this->database_name, $this->port);
        if ($this->conn->connect_error){
            die("connection failed : " . $this->conn->connect_error);
        }
    }

    // Modifikasi metode findAll dan findById di kelas Product

public function findAll(){
    $sql = "SELECT * FROM produk";
    $result = $this->conn->query($sql);
    $this->conn->close();
    $data = [];
    while ($row = $result->fetch_assoc()){
        $data[] = $row;
    }
    return $data;
}

public function findById($id){
    $sql = "SELECT * FROM produk WHERE id_produk = ?";
    $stmt = $this->conn->prepare($sql);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    $this->conn->close();
    $data = [];
    while($row = $result->fetch_assoc()){
        $data[] = $row;
    }
    return $data;
}

public function create($data){
    $nama_sayur = $data["nama_sayur"];
    $warna_sayur = $data["warna_sayur"];
    $id_jenis = $data["id_jenis"];

    $query = "INSERT INTO produk (nama_sayur, warna_sayur, id_jenis) VALUES (?, ?, ?)";
    $stmt = $this->conn->prepare($query);
    $stmt->bind_param("ssi", $nama_sayur, $warna_sayur, $id_jenis);
    $stmt->execute();
    $this->conn->close();
}


public function update($data, $id){
    $nama_sayur = $data["nama_sayur"];
    $warna_sayur = $data["warna_sayur"];
    $id_jenis = $data["id_jenis"];

    $query = "UPDATE produk SET nama_sayur = ?, warna_sayur = ?, id_jenis = ? WHERE id_produk = ?";
    $stmt = $this->conn->prepare($query);

    $stmt->bind_param("ssii", $nama_sayur, $warna_sayur, $id_jenis, $id);
    $stmt->execute();
    $this->conn->close();
}


    public function destroy($id){
        $query = "DELETE FROM produk WHERE id_produk = ?";
        $stmt = $this->conn->prepare($query);

        $stmt->bind_param("i", $id);
        $stmt->execute();
        $this->conn->close();

    }

    public function findAllWithCategories()
    {
        $sql = "SELECT produk.id_produk, produk.nama_sayur, produk.warna_sayur, klasifikasi.jenis_sayur 
        FROM produk 
        RIGHT JOIN klasifikasi ON produk.id_jenis = klasifikasi.id_jenis";

        $result = $this->conn->query($sql);

        // Check for errors in the query execution
        if (!$result) {
            die("Error in SQL query: " . $this->conn->error);
        }

        $data = [];
        while ($row = $result->fetch_assoc()) {
            $data[] = $row;
        }

        $this->conn->close();

        return $data;
    }
}
